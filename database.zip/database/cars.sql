-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: rental
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cars` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `plate_number` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `transmission` varchar(255) DEFAULT NULL,
  `capacity` int(255) DEFAULT NULL,
  `price` int(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `total_amount` varchar(255) DEFAULT '0',
  `car_status` enum('Pending','Available','Approved') DEFAULT 'Available',
  `provider` varchar(255) DEFAULT NULL,
  `date1` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `date2` varchar(10) NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,'HDN216','City Car','2016','Toyota Vios E','Automatic',4,2500,'cover-1527875811788.png','0','Available','1','0','0'),(10,'JSN172','City Car','2018','Toyota Corolla Altis G','Manual',4,2500,'cover-1528078111078.png','0','Available','1','0','0'),(11,'JSN263','Executive Car','2015','Toyota Camry G','Automatic',4,3000,'cover-1528078183103.png','0','Available','1','0000-00-00','0000-00-00'),(12,'FDB725','Sports Utility Vehicle','2014','Honda CR-V SE 5D','Automatic',5,3000,'cover-1528078261912.png','0','Available','1','0000-00-00','0000-00-00'),(13,'HAB374','Sports Utility Vehicle','Toyota Fortuner G','Toyota Fortuner G','Manual',7,4000,'cover-1528078369906.png','0','Available','1','0000-00-00','0000-00-00'),(14,'HDN276','Sports Utility Vehicle','2016','Ford Everest','Automatic',6,4000,'cover-1528078464884.png','0','Available','1','0000-00-00','0000-00-00'),(15,'USG273','People Carrier','2015','Hyundai County Deluxe','Manual',24,6000,'cover-1528079940359.png','0','Available','1','0000-00-00','0000-00-00');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-16 14:52:04
